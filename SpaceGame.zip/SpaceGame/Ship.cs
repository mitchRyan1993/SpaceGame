﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    class Ship
    {
        public int Durability{get;set;}

        public int Fuel { get; set; }

    }
}
